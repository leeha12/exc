var boardElement = document.getElementById('board');
var selectedPicture = null;

var steps = 1;
var sizeOfBoard = 600;

// Calling the InitBoard to setup the board
InitBoard();

// function that handle the upload of image
function uploadPicture(input) {
    // check if have files and if the file is image
    if (input.files && input.files[0] && input.files[0].type.includes("image")) {

        let reader = new FileReader();

        // 2. When is done to read the file
        reader.onload = function (e) {
            // Create image element
            let imgElement = document.createElement('img');
            // Base64 of image
            imgElement.src = e.target.result;

            // Size of image
            imgElement.width = 100;
            imgElement.height = 100;

            // position of image (Random)
            imgElement.style.position = 'absolute';
            imgElement.style.top = Math.floor(Math.random() * 401) + 'px';
            imgElement.style.left = Math.floor(Math.random() * 401) + 'px';

            // Event that if the user click on image
            imgElement.addEventListener('click', () => {
                selectedPicture = imgElement;
            });

            // Add image to board
            boardElement.appendChild(imgElement);
        };
        // 1. read the file
        reader.readAsDataURL(input.files[0]);
    }
}

function handleKeys(event) {
    // Check if the selectedPicture is not null
    if (selectedPicture) {
        // Getting the position of image
        let top = Number(selectedPicture.style.top.split('px')[0]);
        let left = Number(selectedPicture.style.left.split('px')[0]);

        // Checking the key and limit the position to board (not cross the board)
        switch (event.key) {
            case 'ArrowUp':
                if (top > 0) {
                    selectedPicture.style.top = top - steps + 'px';
                }
                break;
            case 'ArrowDown':
                if (top < sizeOfBoard - 100) {
                    selectedPicture.style.top = (top + steps) + 'px';
                }
                break;
            case 'ArrowLeft':
                if (left > 0) {
                    selectedPicture.style.left = (left - steps) + 'px';
                }
                break;
            case 'ArrowRight':
                if (left < sizeOfBoard - 100) {
                    selectedPicture.style.left = (left + steps) + 'px';
                }
                break;
        }
    }
}

function InitBoard() {
    // Keys events
    document.body.addEventListener('keydown', handleKeys);
    boardElement.style.width = sizeOfBoard + 'px';
    boardElement.style.height = sizeOfBoard + 'px';
}